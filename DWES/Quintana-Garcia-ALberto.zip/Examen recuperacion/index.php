<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Examen - Índice</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
  <h1>Examen - Modelo C (DWES)</h1>
  <ul>
    <li><a href="formulario.php">Ejercicio 1 — Números amigos (formulario)</a></li>
    <li><a href="proceso.php">Ejercicio 1 — Proceso (si abres directamente)</a></li>
    <li><a href="ejercicio_cola.php">Ejercicio 2 — Pruebas de la clase Cola</a></li>
  </ul>
</body>
</html>